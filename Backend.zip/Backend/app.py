from flask import Flask, request, jsonify
from flask_cors import CORS
from youtube_transcript_api import YouTubeTranscriptApi
from dotenv import load_dotenv
from urllib.parse import urlparse, parse_qs
import requests
import os
import fitz
import re

load_dotenv()
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"

app = Flask(__name__)
CORS(app, origins="http://localhost:5173")

def extract_video_id(url: str):
    """Extract video ID from YouTube URLs (supports youtube.com and youtu.be)."""
    query = parse_qs(urlparse(url).query)
    if "v" in query:
        return query["v"][0]
    match = re.match(r"(?:https?:\/\/)?(?:www\.)?youtu\.be\/([^\?&]+)", url)
    return match.group(1) if match else None


def openrouter_summarize(text: str):
    """Send text to OpenRouter API for summarization."""
    try:
        headers = {
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": "openai/gpt-3.5-turbo",
            "messages": [
                {"role": "system", "content": "You are an assistant that summarizes text clearly and concisely."},
                {"role": "user", "content": f"Summarize this text:\n\n{text}"}
            ],
            "temperature": 0.3,
            "max_tokens": 400
        }

        response = requests.post(OPENROUTER_URL, headers=headers, json=payload)
        response.raise_for_status()
        result = response.json()

        return {"success": True, "summary": result["choices"][0]["message"]["content"]}
    except Exception as e:
        return {"success": False, "error": f"OpenRouter API failed: {str(e)}"}


@app.route("/summarize/text", methods=["POST"])
def summarize_text():
    data = request.get_json()
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"success": False, "error": "No text provided"}), 400
    return jsonify(openrouter_summarize(text))


@app.route("/summarize/pdf", methods=["POST"])
def summarize_pdf():
    try:
        file = request.files.get("file")
        if not file:
            return jsonify({"success": False, "error": "No PDF uploaded"}), 400

        if not file.filename.lower().endswith(".pdf"):
            return jsonify({"success": False, "error": "Only PDF files are allowed"}), 400

        doc = fitz.open(stream=file.read(), filetype="pdf")
        text = "".join([page.get_text() for page in doc])

        if not text.strip():
            return jsonify({"success": False, "error": "PDF contains no extractable text"}), 400

        return jsonify(openrouter_summarize(text))
    except Exception as e:
        return jsonify({"success": False, "error": f"PDF summarization failed: {str(e)}"}), 500

@app.route("/summarize/youtube", methods=["POST"])
def summarize_youtube():
    try:
        data = request.get_json()
        url = data.get("url", "").strip()
        if not url:
            return jsonify({"success": False, "error": "No YouTube URL provided"}), 400

        print("👉 Received URL:", url)

        # Extract video ID
        video_id = extract_video_id(url)
        print("👉 Extracted video_id:", video_id)

        if not video_id:
            return jsonify({"success": False, "error": "Invalid YouTube URL"}), 400

        # Fetch transcript
        transcript = YouTubeTranscriptApi.fetch(video_id, languages=['en'])
        print("👉 Transcript length:", len(transcript))

        text = " ".join([t['text'] for t in transcript])
        if not text.strip():
            return jsonify({"success": False, "error": "Transcript not available"}), 400

        print("👉 Text sample:", text[:200])  # preview first 200 chars

        # Summarize transcript
        result = openrouter_summarize(text)
        print("👉 Summary result:", result)

        return jsonify(result)

    except Exception as e:
        print("❌ ERROR in summarize_youtube:", str(e))  # <-- log actual error
        return jsonify({"success": False, "error": f"YouTube summarization failed: {str(e)}"}), 500


if __name__ == "__main__":
    app.run(debug=True)
